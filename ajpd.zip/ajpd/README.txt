 1. JDBC Connectivity
 2. JDBC Connectivity & CRUD Operations
3. Data Driven GUI Application
4. A Data Driven Servlet Application
5. Servlet - Session Management
6. Servlet - Request Redirection
7. JSP - User Authentication
8. JSP - Java Beans
9. JSP - Custom Tags
10. JSP - Application Context
